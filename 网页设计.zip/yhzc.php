<?php
include('index.php');
$con=mysqli_connect("localhost","root","123456","wscs");
mysqli_query($con,"set name utf8");
$sjhm=$_GET['sjhm'];
$mm=$_GET['mm'];
//$zx=mysqli_query($conn,"insert into yh(sjhm,mm)values('$sjhm','$mm')");
$zx=mysqli_query($con,"select * from yh where sjhm = '$sjhm' and mm='$mm'");
if($zx){
    echo '<script language="javascript">location.href="home.html"</script>';
}

?>